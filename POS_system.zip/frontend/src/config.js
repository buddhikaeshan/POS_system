const config = {
  // BASE_URL: "https://colkanapi.kandyis.live",
  BASE_URL: "http://localhost:5000",

};

export default config;

//BASE_URL: "https://colkanpos-b-production.up.railway.app",