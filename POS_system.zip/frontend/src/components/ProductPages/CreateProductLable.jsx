import React from 'react'

const CreateProductLable = () => {
  return (
    <div>
      <h4>CreateProductLable</h4>
    </div>
  )
}

export default CreateProductLable