import React from 'react'

const SearchGRN = () => {
  return (
    <div>SearchGRN</div>
  )
}

export default SearchGRN