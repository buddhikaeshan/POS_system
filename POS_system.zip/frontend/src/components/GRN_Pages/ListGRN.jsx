import React from 'react'

const ListGRN = () => {
  return (
    <div>ListGRN</div>
  )
}

export default ListGRN